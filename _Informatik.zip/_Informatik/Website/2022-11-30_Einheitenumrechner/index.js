function convert(){
    let a = 2;
    let b = 3;
    let c = a + b;
    alert("Result: " + c);
}

function slide() {
    window.open("https://discord.cooffeeSystems.cloud", "_blank");
}