package de.cancelcloud;

public class Main {
    public static void main(String[] args) {
    }
}