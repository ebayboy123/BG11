plugins {
    id("java")
}

group = "de.cancelcloud"
version = "1.0"