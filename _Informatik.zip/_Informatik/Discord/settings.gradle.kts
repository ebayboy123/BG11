
rootProject.name = "Discord"

