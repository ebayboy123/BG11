rootProject.name = "BG11"
include("InfotainmentAuto")
include("FahrkartenAutomat")
include("FlugZeug")
