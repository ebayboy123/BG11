package de.cancelcloud;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String PAP = "https://www.figma.com/file/Ms44nLn8H7FdXFgLACBdEV/FahrkartenAutomat?node-id=0%3A1";
        while (true) {
            //Variable definitions
            boolean AZone = false;
            boolean BZone = false;
            boolean CZone = false;
            int ACount = 0;
            int BCount = 0;
            int CCount = 0;
            int ACountTemp = 0;
            int BCountTemp = 0;
            int CCountTemp = 0;
            double ACost = 2.50;
            double BCost = 3.70;
            double CCost = 5.20;
            double moneyneeded = 0.0;
            double moneyTemp = 0.0;
            double moneygiven = 0.0;
            boolean card = false;
            boolean AZoneUnderaged = false;
            boolean BZoneUnderaged = false;
            boolean CZoneUnderaged = false;
            int AZoneUnderAgedCount = 0;
            int BZoneUnderAgedCount = 0;
            int CZoneUnderAgedCount = 0;
            double underagedBonus = 0.5;
            boolean temp = false;




            Scanner scanner = new Scanner(System.in);

            System.out.println("Für welche Zone möchten sie ein Ticket kaufen?");
            System.out.println("Möglichkeiten sind: 'A'         'B'         'C'");
            System.out.println("                   2.50€       3.70€      5.20€");
            switch (scanner.next().toLowerCase()) {
                case "a" -> {
                    System.out.println("Zone 'A' wurde gewählt");
                    AZone = true;
                }
                case "b" -> {
                    System.out.println("Zone 'B' wurde gewählt");
                    BZone = true;
                }
                case "c" -> {
                    System.out.println("Zone 'C' wurde gewählt");
                    CZone = true;
                }

                default -> {
                    System.out.println("Das scheint keine Richtige Eingabe gewesen zu sein, versuchen sie es noch einmal!");
                }
            }

            System.out.println("Wie viele möchten sie kaufen?");
            try {
                String read = scanner.next();
                if (AZone) {
                   ACount=  Integer.parseInt(read);
                } else if (BZone) {
                    BCount=  Integer.parseInt(read);
                } else if (CZone) {
                    CCount=  Integer.parseInt(read);
                }
            } catch (NumberFormatException exception) {
                System.out.println("Das scheinte keine Zahl zu sein! Versuchen sie es noch einmal!");
            }

            System.out.println("Bist du über 18?");
            String answer = scanner.next();

            if (answer.contains("ja") || answer.contains("yes")) temp = true;

            if (AZone) {
                moneyneeded = (ACount * ACost);
                if (temp = true) {
                    moneyneeded = moneyneeded * underagedBonus;
                }
            }
            if (BZone) {
                moneyneeded = (BCount * BCost);
                if (temp = true) {
                    moneyneeded = moneyneeded * underagedBonus;
                }
            }
            if (CZone) {
                moneyneeded = (CCount * CCost);
                if (temp = true) {
                    moneyneeded = moneyneeded * underagedBonus;
                }
            }


            AZone = false;
            BZone = false;
            CZone = false;
            ACount = 0;
            BCount = 0;
            CCount = 0;
            moneyneeded = 0.0;
            moneygiven = 0.0;

             AZoneUnderaged = false;
             BZoneUnderaged = false;
             CZoneUnderaged = false;
             AZoneUnderAgedCount = 0;
             BZoneUnderAgedCount = 0;
             CZoneUnderAgedCount = 0;
            card = false;
        }

    }
}